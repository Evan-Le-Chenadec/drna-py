# TODO 

Stuff I will add in the future/need to do :

1. [ ] Correcting the README.md
2. [X] Finishing the ORF_search function
3. [X] Finishing the DRNA_to_PRT functions
4. [ ] Making proper tests for the Python script
5. [ ] Adding classes for DNA/RNA/PRT strands
6. [ ] Refactoring the functions as methods of the according classes